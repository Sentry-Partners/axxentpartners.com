Axxent Partners Logo Pack
==========================

This pack contains official Axxent Partners logos and emblems.

Folders:
- Wordmarks: Horizontal, transparent, black variants
- Emblems: Standalone emblem + glow
- Monochrome: One-color black and white versions
- Icons: Favicons and app icons

Usage Guidelines:
- Maintain clear space ~0.5x logo height on all sides
- Do not recolor outside brand palette
- Do not skew, stretch, or add effects to the wordmark
- Use Emblem for small spaces, not the full wordmark

Contact: admin@sentry.partners
